<?php
require_once 'php/connection.php';

echo "<h2>Checking Users in Database</h2>";

try {
    $pdo = createPdoConnection();
    
    // Show all users
    $stmt = $pdo->query("SELECT user_id, username, role, status, password FROM user");
    $users = $stmt->fetchAll();
    
    echo "<h3>All Users:</h3>";
    echo "<table border='1' cellpadding='8'>";
    echo "<tr><th>ID</th><th>Username</th><th>Role</th><th>Status</th><th>Password Hash</th></tr>";
    foreach ($users as $user) {
        echo "<tr>";
        echo "<td>" . $user['user_id'] . "</td>";
        echo "<td>" . $user['username'] . "</td>";
        echo "<td>" . $user['role'] . "</td>";
        echo "<td>" . $user['status'] . "</td>";
        echo "<td style='font-size: 12px;'>" . substr($user['password'], 0, 30) . "...</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check specifically for teacher1
    $stmt = $pdo->prepare("SELECT * FROM user WHERE username = :username");
    $stmt->execute([':username' => 'teacher1']);
    $teacher = $stmt->fetch();
    
    if ($teacher) {
        echo "<h3 style='color: green;'>✅ teacher1 found!</h3>";
        
        // Test password verification
        $testPassword = 'password123';
        if (password_verify($testPassword, $teacher['password'])) {
            echo "<p style='color: green;'>✅ Password 'password123' is CORRECT!</p>";
        } else {
            echo "<p style='color: red;'>❌ Password 'password123' is INCORRECT!</p>";
            echo "<p>Let's fix this. The correct hash for 'password123' is:</p>";
            $newHash = password_hash('password123', PASSWORD_DEFAULT);
            echo "<code style='background: #f0f0f0; padding: 10px; display: block;'>" . $newHash . "</code>";
        }
    } else {
        echo "<h3 style='color: red;'>❌ teacher1 NOT found!</h3>";
        echo "<p>Let's create teacher1:</p>";
        
        // Insert teacher1
        $hash = password_hash('password123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO user (username, password, role, status) VALUES (:username, :password, 'Teacher', 'Active')");
        $stmt->execute([
            ':username' => 'teacher1',
            ':password' => $hash
        ]);
        
        $newId = $pdo->lastInsertId();
        echo "<p style='color: green;'>✅ teacher1 created with ID: " . $newId . "</p>";
        echo "<p>Try logging in now!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>