// ============================================================
// STATE
// ============================================================

const state = {
    user: null,
    activeView: 'dashboard',
    chartInstances: {},
    dashboard: {
        my_students: 0,
        class_avg_wcpm: 0,
        my_assessments: 0,
        recent_assessments: [],
        class_performance: []
    },
    students: [],
    materials: [],
    assessments: [],
    importPreview: null,
    importFile: null
};

// ============================================================
// DOM REFS
// ============================================================

const loginView = document.getElementById('login-view');
const appShell = document.getElementById('app-shell');
const viewContainer = document.getElementById('view-container');
const navContainer = document.getElementById('nav-container');
const userBadge = document.getElementById('user-badge');
const roleBadge = document.getElementById('role-badge');
const loginForm = document.getElementById('login-form');
const logoutBtn = document.getElementById('logout-btn');

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function fetchJson(url, options = {}) {
    const headers = options.headers || {};
    if (options.body && !headers['Content-Type']) {
        headers['Content-Type'] = 'application/json';
    }
    return fetch(url, { 
        credentials: 'same-origin', 
        ...options, 
        headers 
    }).then(async (response) => {
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
            throw new Error(data.message || 'Request failed');
        }
        return data;
    });
}

function showLogin() {
    loginView.classList.remove('hidden');
    appShell.classList.add('hidden');
    document.body.className = '';
}

function showApp() {
    loginView.classList.add('hidden');
    appShell.classList.remove('hidden');
    
    const user = state.user;
    if (user) {
        userBadge.textContent = user.username || 'User';
        if (roleBadge) roleBadge.textContent = user.role || 'Guest';
        
        // Apply role theme
        document.body.className = 'role-' + (user.role || '').toLowerCase();
        
        // Update date
        const now = new Date();
        const dateEl = document.getElementById('current-date');
        if (dateEl) {
            dateEl.textContent = now.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
        }
    }
}

function setActiveView(viewName) {
    state.activeView = viewName;
    document.querySelectorAll('.nav-btn').forEach((btn) => {
        btn.classList.toggle('active', btn.dataset.view === viewName);
    });
    renderView();
}

// ============================================================
// RENDER NAVIGATION
// ============================================================

function renderNavigation() {
    if (!navContainer) return;
    
    const user = state.user;
    const role = user ? user.role : 'Guest';
    
    let navButtons = '';
    
    switch(role) {
        case 'Admin':
        case 'Principal':
            navButtons = `
                <button class="nav-btn active" data-view="dashboard">📊 Dashboard</button>
                <button class="nav-btn" data-view="teachers">👨‍🏫 Teachers</button>
                <button class="nav-btn" data-view="students">👨‍🎓 Students</button>
                <button class="nav-btn" data-view="materials">📚 Library</button>
                <button class="nav-btn" data-view="assessment">📝 Assessments</button>
                <button class="nav-btn" data-view="reports">📈 Reports</button>
            `;
            break;
            
        case 'Teacher':
            navButtons = `
                <button class="nav-btn active" data-view="dashboard">📊 Dashboard</button>
                <button class="nav-btn" data-view="students">👨‍🎓 My Students</button>
                <button class="nav-btn" data-view="materials">📚 Library</button>
                <button class="nav-btn" data-view="assessment">📝 Assessments</button>
                <button class="nav-btn" data-view="reports">📈 Reports</button>
            `;
            break;
            
        case 'Student':
            navButtons = `
                <button class="nav-btn active" data-view="dashboard">📊 My Dashboard</button>
                <button class="nav-btn" data-view="library">📚 My Library</button>
                <button class="nav-btn" data-view="reading">📖 Read</button>
                <button class="nav-btn" data-view="progress">📈 My Progress</button>
            `;
            break;
            
        case 'Parent':
            navButtons = `
                <button class="nav-btn active" data-view="dashboard">📊 Dashboard</button>
                <button class="nav-btn" data-view="children">👨‍👩‍👦 My Children</button>
                <button class="nav-btn" data-view="progress">📈 Progress</button>
            `;
            break;
            
        default:
            navButtons = `
                <button class="nav-btn active" data-view="dashboard">Dashboard</button>
            `;
    }
    
    navContainer.innerHTML = navButtons;
    
    document.querySelectorAll('.nav-btn').forEach((btn) => {
        btn.addEventListener('click', () => setActiveView(btn.dataset.view));
    });
}

// ============================================================
// RENDER VIEW
// ============================================================

function renderView() {
    const role = state.user ? state.user.role : 'Guest';
    
    // Clear any existing charts
    if (state.chartInstances) {
        Object.values(state.chartInstances).forEach(chart => {
            if (chart && chart.destroy) chart.destroy();
        });
        state.chartInstances = {};
    }
    
    switch(state.activeView) {
        case 'dashboard':
            if (role === 'Principal' || role === 'Admin') {
                renderPrincipalDashboard();
            } else if (role === 'Teacher') {
                renderTeacherDashboard();
            } else if (role === 'Student') {
                renderStudentDashboard();
            } else if (role === 'Parent') {
                renderParentDashboard();
            } else {
                renderDefaultDashboard();
            }
            break;
        case 'students':
            renderStudents();
            break;
        case 'materials':
            renderMaterials();
            break;
        case 'assessment':
            renderAssessment();
            break;
        case 'reports':
            renderReports();
            break;
        default:
            renderTeacherDashboard();
    }
}

// ============================================================
// TEACHER DASHBOARD
// ============================================================

function renderTeacherDashboard() {
    const stats = state.dashboard || {
        my_students: 0,
        class_avg_wcpm: 0,
        my_assessments: 0,
        recent_assessments: [],
        class_performance: []
    };
    
    viewContainer.innerHTML = `
        <!-- Stats Cards -->
        <div class="grid three">
            <div class="stat-card" style="border-top: 4px solid #dc2626;">
                <h4>👨‍🎓 My Students</h4>
                <p class="stat-number">${stats.my_students || 0}</p>
                <span class="stat-label">Active students</span>
            </div>
            <div class="stat-card" style="border-top: 4px solid #dc2626;">
                <h4>📊 Class Avg WCPM</h4>
                <p class="stat-number">${stats.class_avg_wcpm ? stats.class_avg_wcpm.toFixed(1) : '0'}</p>
                <span class="stat-label">Words per minute</span>
            </div>
            <div class="stat-card" style="border-top: 4px solid #dc2626;">
                <h4>📝 Assessments</h4>
                <p class="stat-number">${stats.my_assessments || 0}</p>
                <span class="stat-label">This month</span>
            </div>
        </div>

        <!-- Start Reading Activity -->
        <div class="panel" style="margin-top: 20px; background: linear-gradient(135deg, #fef2f2, #fff); border-left: 4px solid #dc2626;">
            <h3>🎯 Start Reading Activity</h3>
            <div style="display: grid; gap: 12px; max-width: 600px;">
                <div style="display: grid; gap: 4px;">
                    <label style="font-weight: 500;">Enter Student ID</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="text" id="student-id-input" placeholder="e.g. STU-001 or 001" style="flex:1; padding: 10px; border: 1px solid var(--border); border-radius: 10px;">
                        <button id="search-student-btn" class="btn-primary" style="background: #dc2626;">🔍 Search</button>
                    </div>
                </div>
                <div id="student-search-result" style="padding: 12px; background: #f8fafc; border-radius: 10px; display: none;">
                    <p><strong>Student Found:</strong> <span id="found-student-name">-</span></p>
                    <p><strong>Grade:</strong> <span id="found-student-grade">-</span></p>
                    <p><strong>Section:</strong> <span id="found-student-section">-</span></p>
                </div>
                <button id="start-assessment-btn" class="btn-primary" style="background: #dc2626; width: fit-content; padding: 12px 24px;">
                    🚀 Start Assessment
                </button>
            </div>
        </div>

        <!-- Charts and Recent Assessments -->
        <div class="grid two" style="margin-top: 20px;">
            <div class="panel">
                <h3>📈 Class Performance</h3>
                ${stats.class_performance && stats.class_performance.length ? 
                    `<div class="chart-container" style="height: 250px;">
                        <canvas id="classPerformanceChart"></canvas>
                    </div>
                    <div class="legend">
                        <span><span class="dot" style="background: #2563eb;"></span> Accuracy</span>
                        <span><span class="dot" style="background: #16a34a;"></span> Fluency</span>
                        <span><span class="dot" style="background: #f59e0b;"></span> Reading Rate</span>
                    </div>` 
                    : '<p class="empty">No assessment data available yet. Complete reading activities to see performance.</p>'
                }
            </div>
            <div class="panel">
                <h3>📝 Recent Assessments</h3>
                ${stats.recent_assessments && stats.recent_assessments.length ? 
                    `<table>
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Accuracy</th>
                                <th>Fluency</th>
                                <th>Rate</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${stats.recent_assessments.map(item => `
                                <tr>
                                    <td><strong>${item.student_name || 'Unknown'}</strong><br>
                                        <small style="color: var(--muted);">${item.assessed_at ? new Date(item.assessed_at).toLocaleDateString() : 'N/A'}</small>
                                    </td>
                                    <td>${item.accuracy_percentage || 0}%</td>
                                    <td>${item.fluency_score || 0}</td>
                                    <td>${item.wcpm || 0}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>` 
                    : '<p class="empty">No recent assessments. Start reading activities to collect data.</p>'
                }
            </div>
        </div>
    `;
    
    // Initialize chart if data exists
    if (stats.class_performance && stats.class_performance.length) {
        setTimeout(() => {
            initTeacherChart(stats.class_performance);
        }, 100);
    }
    
    // Attach event listeners for the reading activity
    document.getElementById('search-student-btn')?.addEventListener('click', searchStudent);
    document.getElementById('start-assessment-btn')?.addEventListener('click', startAssessment);
    document.getElementById('student-id-input')?.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') searchStudent();
    });
}

// ============================================================
// TEACHER CHART
// ============================================================

function initTeacherChart(performanceData) {
    const ctx = document.getElementById('classPerformanceChart');
    if (!ctx) return;
    
    // Destroy existing chart if any
    if (state.chartInstances.teacher) {
        state.chartInstances.teacher.destroy();
    }
    
    const labels = performanceData.map(item => item.grade_level || 'Unknown');
    const accuracy = performanceData.map(item => parseFloat(item.avg_accuracy) || 0);
    const fluency = performanceData.map(item => parseFloat(item.avg_fluency) || 0);
    const rate = performanceData.map(item => parseFloat(item.avg_rate) || 0);
    
    state.chartInstances.teacher = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Accuracy (%)',
                    data: accuracy,
                    backgroundColor: 'rgba(37, 99, 235, 0.6)',
                    borderColor: 'rgba(37, 99, 235, 1)',
                    borderWidth: 2
                },
                {
                    label: 'Fluency',
                    data: fluency,
                    backgroundColor: 'rgba(22, 163, 74, 0.6)',
                    borderColor: 'rgba(22, 163, 74, 1)',
                    borderWidth: 2
                },
                {
                    label: 'Reading Rate',
                    data: rate,
                    backgroundColor: 'rgba(245, 158, 11, 0.6)',
                    borderColor: 'rgba(245, 158, 11, 1)',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

// ============================================================
// STUDENT SEARCH (for reading activity)
// ============================================================

async function searchStudent() {
    const input = document.getElementById('student-id-input');
    const resultDiv = document.getElementById('student-search-result');
    const nameSpan = document.getElementById('found-student-name');
    const gradeSpan = document.getElementById('found-student-grade');
    const sectionSpan = document.getElementById('found-student-section');
    
    const studentId = input.value.trim();
    if (!studentId) {
        alert('Please enter a Student ID');
        return;
    }
    
    try {
        const data = await fetchJson(`php/api/modules/students.php?action=search&term=${encodeURIComponent(studentId)}`);
        if (data.students && data.students.length > 0) {
            const student = data.students[0];
            nameSpan.textContent = `${student.first_name} ${student.last_name}`;
            gradeSpan.textContent = student.grade_level || 'N/A';
            sectionSpan.textContent = student.section || 'N/A';
            resultDiv.style.display = 'block';
            resultDiv.style.borderLeft = '4px solid #22c55e';
        } else {
            nameSpan.textContent = '❌ Student not found';
            gradeSpan.textContent = '-';
            sectionSpan.textContent = '-';
            resultDiv.style.display = 'block';
            resultDiv.style.borderLeft = '4px solid #dc2626';
        }
    } catch (error) {
        alert('Error searching for student: ' + error.message);
    }
}

function startAssessment() {
    const input = document.getElementById('student-id-input');
    const studentId = input.value.trim();
    if (!studentId) {
        alert('Please enter a Student ID first');
        return;
    }
    alert(`Starting assessment for student: ${studentId}\n\nStep 1: Select reading material\nStep 2: Record reading\nStep 3: Get ORF scores\n\nThis will be implemented in the next phase!`);
}

// ============================================================
// OTHER DASHBOARDS (Placeholders for now)
// ============================================================

function renderPrincipalDashboard() {
    viewContainer.innerHTML = `
        <div class="panel">
            <h3>📊 Principal Dashboard</h3>
            <p>Welcome, ${state.user ? state.user.username : ''}!</p>
            <p>This dashboard will show:</p>
            <ul>
                <li>Total Students</li>
                <li>Teachers</li>
                <li>Avg WCPM</li>
                <li>Assessments</li>
                <li>Performance by Grade Level</li>
                <li>Students at Risk</li>
            </ul>
            <p style="color: var(--muted);">Coming soon!</p>
        </div>
    `;
}

function renderStudentDashboard() {
    viewContainer.innerHTML = `
        <div class="panel">
            <h3>👨‍🎓 Student Dashboard</h3>
            <p>Welcome, ${state.user ? state.user.username : ''}!</p>
            <p>This dashboard will show:</p>
            <ul>
                <li>Books Read</li>
                <li>Avg Score</li>
                <li>Reading Progress</li>
                <li>My Library</li>
            </ul>
            <p style="color: var(--muted);">Coming soon!</p>
        </div>
    `;
}

function renderParentDashboard() {
    viewContainer.innerHTML = `
        <div class="panel">
            <h3>👨‍👩‍👦 Parent Dashboard</h3>
            <p>Welcome, ${state.user ? state.user.username : ''}!</p>
            <p>This dashboard will show:</p>
            <ul>
                <li>My Children</li>
                <li>Progress Overview</li>
            </ul>
            <p style="color: var(--muted);">Coming soon!</p>
        </div>
    `;
}

function renderDefaultDashboard() {
    viewContainer.innerHTML = `
        <div class="panel">
            <h3>Welcome to ArchiveVox!</h3>
            <p>Please login to access your dashboard.</p>
        </div>
    `;
}

// ============================================================
// MATERIALS VIEW (Placeholder)
// ============================================================

function renderMaterials() {
    viewContainer.innerHTML = `
        <div class="panel">
            <h3>📚 Library</h3>
            <p>Reading materials management coming soon!</p>
        </div>
    `;
}

// ============================================================
// ASSESSMENT VIEW (Placeholder)
// ============================================================

function renderAssessment() {
    viewContainer.innerHTML = `
        <div class="panel">
            <h3>📝 Assessments</h3>
            <p>Assessment management coming soon!</p>
        </div>
    `;
}

// ============================================================
// REPORTS VIEW (Placeholder)
// ============================================================

function renderReports() {
    viewContainer.innerHTML = `
        <div class="panel">
            <h3>📈 Reports</h3>
            <p>Reports and analytics coming soon!</p>
        </div>
    `;
}

// ============================================================
// LOAD DASHBOARD DATA
// ============================================================

async function loadDashboardData() {
    const user = state.user;
    if (!user) return;
    
    try {
        let data;
        if (user.role === 'Teacher') {
            data = await fetchJson('php/api/modules/reports.php?action=teacher');
        } else if (user.role === 'Principal' || user.role === 'Admin') {
            data = await fetchJson('php/api/modules/reports.php?action=principal');
        } else {
            return;
        }
        
        if (data.success && data.dashboard) {
            state.dashboard = data.dashboard;
            if (state.activeView === 'dashboard') {
                renderView();
            }
        }
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// ============================================================
// LOAD FUNCTIONS (for other data)
// ============================================================

async function loadDashboard() {
    await loadDashboardData();
}

// ============================================================
// STUDENT MANAGEMENT
// ============================================================

async function loadStudents() {
    try {
        const data = await fetchJson('php/api/modules/students.php?action=list');
        if (data.success) {
            state.students = data.students || [];
            if (state.activeView === 'students') {
                renderStudents();
            }
        }
    } catch (error) {
        console.error('Error loading students:', error);
    }
}

function renderStudents() {
    const students = state.students || [];
    
    viewContainer.innerHTML = `
        <div class="page-header">
            <div class="page-header-left">
                <h2>👨‍🎓 Student Management</h2>
                <p class="subtitle">Manage your students and track their reading progress</p>
            </div>
            <div class="page-header-right">
                <button id="add-student-btn" class="btn-primary">➕ Add Student</button>
                <button id="import-students-btn" class="btn-secondary">📤 Import</button>
                <button id="refresh-students-btn" class="btn-secondary">🔄 Refresh</button>
            </div>
        </div>
        
        <div class="search-bar">
            <input type="text" id="student-search-input" placeholder="Search by LRN, name, or section..." style="flex:1; padding: 10px; border: 1px solid var(--border); border-radius: 10px;">
            <button id="search-students-btn" class="btn-primary">🔍 Search</button>
        </div>
        
        <div class="panel" style="margin-top: 20px; overflow-x: auto;">
            ${students.length ? `
                <table>
                    <thead>
                        <tr>
                            <th>LRN</th>
                            <th>Name</th>
                            <th>Grade</th>
                            <th>Section</th>
                            <th>Activities</th>
                            <th>Last Assessed</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${students.map(student => `
                            <tr>
                                <td><strong>${student.lrn || '—'}</strong></td>
                                <td>${student.last_name}, ${student.first_name} ${student.middle_name ? student.middle_name : ''}</td>
                                <td>${student.grade_level || '—'}</td>
                                <td>${student.section || '—'}</td>
                                <td>${student.activity_count || 0}</td>
                                <td>${student.last_assessed ? new Date(student.last_assessed).toLocaleDateString() : '—'}</td>
                                <td><span class="status-badge ${student.is_active ? 'active' : 'archived'}">${student.is_active ? 'Active' : 'Archived'}</span></td>
                                <td>
                                    <button class="action-btn edit-student" data-id="${student.student_id}">✏️</button>
                                    <button class="action-btn archive-student" data-id="${student.student_id}">📁</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            ` : `
                <div class="empty-state">
                    <p>📚 No students added yet</p>
                    <p style="color: var(--muted);">Click "Add Student" to add your first student, or "Import" to bulk upload</p>
                </div>
            `}
        </div>
        
        <!-- Add Student Modal -->
        <div id="add-student-modal" class="modal hidden">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>➕ Add Student</h3>
                    <button class="close-modal">✕</button>
                </div>
                <form id="add-student-form">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>LRN (6 digits) *</label>
                            <input type="text" name="lrn" placeholder="e.g. 123456" maxlength="6" required>
                            <small style="color: var(--muted);">Unique 6-digit Learner Reference Number</small>
                        </div>
                        <div class="form-group">
                            <label>First Name *</label>
                            <input type="text" name="first_name" required>
                        </div>
                        <div class="form-group">
                            <label>Middle Name</label>
                            <input type="text" name="middle_name">
                        </div>
                        <div class="form-group">
                            <label>Last Name *</label>
                            <input type="text" name="last_name" required>
                        </div>
                        <div class="form-group">
                            <label>Grade Level</label>
                            <select name="grade_level">
                                <option value="Grade 2">Grade 2</option>
                                <option value="Grade 3">Grade 3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Section</label>
                            <input type="text" name="section" placeholder="e.g. Section A">
                        </div>
                        <div class="form-group">
                            <label>Gender</label>
                            <select name="gender">
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Birthdate</label>
                            <input type="date" name="birthdate">
                        </div>
                    </div>
                    <div class="modal-actions">
                        <button type="submit" class="btn-primary">💾 Save Student</button>
                        <button type="button" class="btn-secondary close-modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Import Modal -->
        <div id="import-modal" class="modal hidden">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>📤 Import Students</h3>
                    <button class="close-modal">✕</button>
                </div>
                <div class="import-instructions">
                    <p>Upload a CSV or Excel file with student data.</p>
                    <p><strong>Required columns:</strong> lrn, first_name, last_name</p>
                    <p><strong>Optional:</strong> middle_name, grade_level, section, gender, birthdate</p>
                    <div style="background: #f0fdf4; padding: 8px 12px; border-radius: 8px; margin-top: 8px; border-left: 4px solid #22c55e;">
                        <p style="margin: 0; font-size: 0.85rem; color: #166534;">
                            💡 <strong>Tip:</strong> LRN should be a 6-digit number (e.g., 123456)
                        </p>
                    </div>
                    <div style="margin-top: 12px;">
                        <a href="#" id="download-sample-csv" style="color: #2563eb; text-decoration: none; font-size: 0.9rem;">
                            📥 Download sample CSV template
                        </a>
                    </div>
                </div>
                <form id="import-form" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Select File (CSV or Excel)</label>
                        <input type="file" name="file" accept=".csv,.xlsx" required>
                    </div>
                    <div class="modal-actions">
                        <button type="submit" class="btn-primary">📤 Import</button>
                        <button type="button" class="btn-secondary close-modal">Cancel</button>
                    </div>
                </form>
                <div id="import-result"></div>
            </div>
        </div>
    `;
    
    // Attach event listeners
    document.getElementById('add-student-btn')?.addEventListener('click', () => showModal('add-student-modal'));
    document.getElementById('import-students-btn')?.addEventListener('click', () => showModal('import-modal'));
    document.getElementById('refresh-students-btn')?.addEventListener('click', loadStudents);
    document.getElementById('search-students-btn')?.addEventListener('click', searchStudents);
    
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden'));
        });
    });
    
    document.querySelectorAll('.edit-student').forEach(btn => {
        btn.addEventListener('click', () => editStudent(btn.dataset.id));
    });
    
    document.querySelectorAll('.archive-student').forEach(btn => {
        btn.addEventListener('click', () => archiveStudent(btn.dataset.id));
    });
    
    // Add Student Form
    document.getElementById('add-student-form')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());
        
        try {
            const result = await fetchJson('php/api/modules/students.php', {
                method: 'POST',
                body: JSON.stringify(data)
            });
            
            if (result.success) {
                alert('✅ Student added successfully!');
                document.getElementById('add-student-modal').classList.add('hidden');
                await loadStudents();
            } else {
                alert('❌ ' + result.message);
            }
        } catch (error) {
            alert('❌ ' + error.message);
        }
    });
    
    // Import Form
    document.getElementById('import-form')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const resultDiv = document.getElementById('import-result');
        resultDiv.innerHTML = '<p>⏳ Processing file...</p>';
        
        try {
            const response = await fetch('php/api/modules/student-import.php?action=preview', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            });
            const data = await response.json();
            
            if (data.success && data.preview) {
                const preview = data.preview;
                
                let html = `
                    <div class="import-preview">
                        <h4>📋 Preview</h4>
                        <p><strong>Total rows:</strong> ${preview.summary.total}</p>
                        <p><strong>Valid rows:</strong> ${preview.summary.valid}</p>
                        <p><strong>Errors:</strong> ${preview.summary.errors}</p>
                `;
                
                if (preview.rows && preview.rows.length > 0) {
                    html += `
                        <div style="max-height: 200px; overflow-y: auto; margin: 12px 0; border: 1px solid var(--border); border-radius: 8px;">
                            <table style="font-size: 0.85rem;">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>LRN</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Grade</th>
                                        <th>Section</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${preview.rows.slice(0, 10).map(row => `
                                        <tr>
                                            <td>${row.row_number}</td>
                                            <td>${row.lrn || '—'}</td>
                                            <td>${row.first_name}</td>
                                            <td>${row.last_name}</td>
                                            <td>${row.grade_level || '—'}</td>
                                            <td>${row.section || '—'}</td>
                                        </tr>
                                    `).join('')}
                                    ${preview.rows.length > 10 ? `<tr><td colspan="6">... and ${preview.rows.length - 10} more</td></tr>` : ''}
                                </tbody>
                            </table>
                        </div>
                    `;
                }
                
                if (preview.errors && preview.errors.length > 0) {
                    html += `
                        <div style="background: #fee2e2; padding: 8px; border-radius: 8px; margin: 8px 0;">
                            <p style="color: #dc2626; margin: 0;"><strong>⚠️ ${preview.errors.length} error(s):</strong></p>
                            <ul style="font-size: 0.85rem; margin: 4px 0;">
                                ${preview.errors.slice(0, 5).map(err => `
                                    <li>Row ${err.row_number}: ${err.message}</li>
                                `).join('')}
                                ${preview.errors.length > 5 ? `<li>... and ${preview.errors.length - 5} more</li>` : ''}
                            </ul>
                        </div>
                    `;
                }
                
                if (preview.summary.valid > 0) {
                    html += `
                        <button id="confirm-import-btn" class="btn-primary" style="margin-top: 12px;">
                            ✅ Confirm Import (${preview.summary.valid} students)
                        </button>
                    `;
                }
                
                html += `</div>`;
                resultDiv.innerHTML = html;
                
                document.getElementById('confirm-import-btn')?.addEventListener('click', async () => {
                    const confirmBtn = document.getElementById('confirm-import-btn');
                    confirmBtn.textContent = '⏳ Importing...';
                    confirmBtn.disabled = true;
                    
                    try {
                        const response2 = await fetch('php/api/modules/student-import.php?action=import', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ rows: preview.rows }),
                            credentials: 'same-origin'
                        });
                        
                        const result2 = await response2.json();
                        
                        if (result2.success) {
                            alert(`✅ Import complete!\n\n📥 Imported: ${result2.summary.imported}\n⏭️ Skipped: ${result2.summary.skipped}\n❌ Errors: ${result2.summary.errors}`);
                            document.getElementById('import-modal').classList.add('hidden');
                            await loadStudents();
                        } else {
                            alert('❌ Import failed: ' + (result2.message || 'Unknown error'));
                        }
                    } catch (error) {
                        alert('❌ Error during import: ' + error.message);
                    }
                });
                
            } else {
                resultDiv.innerHTML = `<p style="color: red;">❌ ${data.message || 'Failed to preview file'}</p>`;
            }
        } catch (error) {
            resultDiv.innerHTML = `<p style="color: red;">❌ Error: ${error.message}</p>`;
        }
    });
    
    // Download sample CSV
    document.getElementById('download-sample-csv')?.addEventListener('click', function(e) {
        e.preventDefault();
        
        const csvContent = `lrn,first_name,last_name,middle_name,grade_level,section,gender,birthdate
123456,Juan,Dela Cruz,Santos,Grade 2,Section A,Male,2016-05-15
123457,Maria,Garcia,Reyes,Grade 2,Section A,Female,2016-08-22
123458,Jose,Luna,Mendoza,Grade 2,Section B,Male,2016-11-02
123459,Ana,Martinez,Cruz,Grade 3,Section A,Female,2015-03-10
123460,Pedro,Santos,Ramos,Grade 3,Section A,Male,2015-07-19`;
        
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'sample_students.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    });
}

function showModal(modalId) {
    document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden'));
    document.getElementById(modalId).classList.remove('hidden');
}

async function searchStudents() {
    const term = document.getElementById('student-search-input')?.value || '';
    if (term.length < 2) {
        await loadStudents();
        return;
    }
    
    try {
        const data = await fetchJson(`php/api/modules/students.php?action=search&term=${encodeURIComponent(term)}`);
        state.students = data.students || [];
        renderStudents();
    } catch (error) {
        console.error('Search error:', error);
    }
}

async function editStudent(studentId) {
    // TODO: Implement edit functionality
    alert(`Edit student ${studentId} - Coming soon!`);
}

async function archiveStudent(studentId) {
    if (!confirm('Are you sure you want to archive this student?')) return;
    
    try {
        const result = await fetchJson(`php/api/modules/students.php?id=${studentId}`, {
            method: 'DELETE'
        });
        
        if (result.success) {
            alert('✅ Student archived successfully');
            await loadStudents();
        } else {
            alert('❌ ' + result.message);
        }
    } catch (error) {
        alert('❌ ' + error.message);
    }
}

async function loadMaterials() {
    try {
        const data = await fetchJson('php/api/modules/reading-materials.php?action=list');
        state.materials = data.materials || [];
    } catch (error) {
        console.error('Error loading materials:', error);
    }
}

async function loadAssessments() {
    try {
        const data = await fetchJson('php/api/modules/assessment.php?action=list');
        state.assessments = data.assessments || [];
    } catch (error) {
        console.error('Error loading assessments:', error);
    }
}

// ============================================================
// SESSION CHECK
// ============================================================

async function checkSession() {
    try {
        const data = await fetchJson('php/api/auth/session.php');
        state.user = data.user || null;
        if (state.user) {
            showApp();
            renderNavigation();
            await loadDashboardData();
            renderView();
        } else {
            showLogin();
        }
    } catch (error) {
        showLogin();
    }
}

// ============================================================
// EVENT LISTENERS
// ============================================================

// Login
loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const formData = new FormData(loginForm);
    try {
        const data = await fetchJson('php/api/auth/login.php', {
            method: 'POST',
            body: JSON.stringify({
                username: formData.get('username'),
                password: formData.get('password')
            })
        });
        state.user = data.user || null;
        showApp();
        renderNavigation();
        await loadDashboardData();
        renderView();
    } catch (error) {
        alert('❌ ' + error.message);
    }
});

// Logout
logoutBtn.addEventListener('click', async () => {
    try {
        await fetchJson('php/api/auth/logout.php');
        state.user = null;
        showLogin();
    } catch (error) {
        console.error('Logout error:', error);
    }
});

// ============================================================
// INIT
// ============================================================

window.addEventListener('DOMContentLoaded', checkSession);