<?php
echo "<h2>Testing Import Functions</h2>";

// Test database connection
require_once 'php/connection.php';
try {
    $pdo = createPdoConnection();
    echo "<p style='color: green;'>✅ Database connected</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database error: " . $e->getMessage() . "</p>";
    exit;
}

// Test student_import functions
require_once 'php/modules/student_import.php';

echo "<h3>Testing parseImportFile with CSV</h3>";

// Create a test CSV
$testCsv = __DIR__ . '/test_import.csv';
$csvContent = "student_no,first_name,last_name,middle_name,grade_level,section,gender,birthdate\n";
$csvContent .= "2025-001,Juan,Dela Cruz,Santos,Grade 2,Section A,Male,2016-05-15\n";
$csvContent .= "2025-002,Maria,Garcia,Reyes,Grade 2,Section A,Female,2016-08-22\n";

file_put_contents($testCsv, $csvContent);

try {
    $rows = parseImportFile($testCsv);
    echo "<p style='color: green;'>✅ Parsed " . count($rows) . " rows</p>";
    echo "<pre>";
    print_r($rows);
    echo "</pre>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Parse error: " . $e->getMessage() . "</p>";
}

echo "<h3>Testing previewStudents</h3>";
try {
    $preview = previewStudents($rows);
    echo "<p style='color: green;'>✅ Preview generated</p>";
    echo "<p>Valid: " . $preview['summary']['valid'] . "</p>";
    echo "<p>Errors: " . $preview['summary']['errors'] . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Preview error: " . $e->getMessage() . "</p>";
}

echo "<h3>Testing importStudents</h3>";
try {
    // Get teacher ID
    $stmt = $pdo->prepare('SELECT teacher_id FROM teacher LIMIT 1');
    $stmt->execute();
    $teacher = $stmt->fetch();
    
    if ($teacher) {
        $result = importStudents($rows, $teacher['teacher_id']);
        echo "<p style='color: green;'>✅ Import completed</p>";
        echo "<pre>";
        print_r($result);
        echo "</pre>";
    } else {
        echo "<p style='color: red;'>❌ No teacher found</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Import error: " . $e->getMessage() . "</p>";
}

// Clean up
unlink($testCsv);
?>