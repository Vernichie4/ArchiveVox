<?php
echo "<h2>Testing Login Directly</h2>";

// Test database connection
require_once 'php/connection.php';
$pdo = createPdoConnection();

// Check if teacher1 exists
$stmt = $pdo->prepare('SELECT user_id, username, password, role, status FROM user WHERE username = :username');
$stmt->execute([':username' => 'teacher1']);
$user = $stmt->fetch();

if ($user) {
    echo "<p style='color: green;'>✅ User found: " . $user['username'] . "</p>";
    echo "<p>Role: " . $user['role'] . "</p>";
    echo "<p>Status: " . $user['status'] . "</p>";
    echo "<p>Password hash: " . $user['password'] . "</p>";
    
    // Test password verification
    $testPassword = 'password123';
    if (password_verify($testPassword, $user['password'])) {
        echo "<p style='color: green;'>✅ Password 'password123' matches!</p>";
    } else {
        echo "<p style='color: red;'>❌ Password 'password123' does NOT match!</p>";
        
        // Show what the hash should be for 'password123'
        $newHash = password_hash('password123', PASSWORD_DEFAULT);
        echo "<p>The correct hash for 'password123' is:</p>";
        echo "<code>" . $newHash . "</code>";
        echo "<p>Your current hash is:</p>";
        echo "<code>" . $user['password'] . "</code>";
    }
} else {
    echo "<p style='color: red;'>❌ User 'teacher1' not found</p>";
}

// Show all users
$stmt = $pdo->query('SELECT user_id, username, role, status FROM user');
$users = $stmt->fetchAll();
echo "<h3>All Users:</h3>";
echo "<ul>";
foreach ($users as $u) {
    echo "<li>" . $u['username'] . " (" . $u['role'] . ") - " . $u['status'] . "</li>";
}
echo "</ul>";
?>