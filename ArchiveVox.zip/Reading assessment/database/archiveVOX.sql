-- ============================================================
-- ArchiveVox Database Schema
-- Version: 2.0 (Complete)
-- Description: Full database schema for ArchiveVox reading assessment system
-- Compatible with: MySQL 8+, MariaDB 10.4+
-- ============================================================

-- ============================================================
-- DROP DATABASE IF EXISTS (Use with caution!)
-- ============================================================

DROP DATABASE IF EXISTS archivevox;
CREATE DATABASE archivevox;
USE archivevox;

-- ============================================================
-- 1. USER TABLE (Authentication)
-- ============================================================

CREATE TABLE user (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Principal', 'Teacher', 'Parent', 'Student') NOT NULL,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME NULL,
    
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 2. PRINCIPAL TABLE
-- ============================================================

CREATE TABLE principal (
    principal_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    employee_no VARCHAR(30) UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    contact_number VARCHAR(20),
    
    FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE,
    
    INDEX idx_employee (employee_no),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 3. TEACHER CATEGORY
-- ============================================================

CREATE TABLE teacher_category (
    teacher_category_id INT AUTO_INCREMENT PRIMARY KEY,
    grade_level ENUM('Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6') NOT NULL,
    section VARCHAR(50) NOT NULL,
    school_year VARCHAR(20) NOT NULL,
    
    UNIQUE KEY unique_teacher_category (grade_level, section, school_year),
    INDEX idx_grade (grade_level),
    INDEX idx_school_year (school_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 4. TEACHER TABLE
-- ============================================================

CREATE TABLE teacher (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    teacher_category_id INT NOT NULL,
    employee_no VARCHAR(30) UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    contact_number VARCHAR(20),
    
    FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_category_id) REFERENCES teacher_category(teacher_category_id) ON DELETE RESTRICT,
    
    INDEX idx_employee (employee_no),
    INDEX idx_email (email),
    INDEX idx_teacher_category (teacher_category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 5. STUDENT CATEGORY
-- ============================================================

CREATE TABLE student_category (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    grade_level ENUM('Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6') NOT NULL,
    school_year VARCHAR(20) NOT NULL,
    
    UNIQUE KEY unique_student_category (grade_level, school_year),
    INDEX idx_grade (grade_level),
    INDEX idx_school_year (school_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 6. CLASS TABLE
-- ============================================================

CREATE TABLE class (
    class_id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    grade_level ENUM('Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6'),
    section VARCHAR(50),
    school_year VARCHAR(20),
    
    FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id) ON DELETE RESTRICT,
    
    INDEX idx_teacher (teacher_id),
    INDEX idx_grade_section (grade_level, section),
    INDEX idx_school_year (school_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 7. STUDENT TABLE (With LRN as Primary Identifier)
-- ============================================================

CREATE TABLE student (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    lrn VARCHAR(20) UNIQUE NOT NULL,  -- 6-digit Learner Reference Number
    teacher_id INT NOT NULL,
    category_id INT NOT NULL,
    class_id INT,
    
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    last_name VARCHAR(50) NOT NULL,
    
    gender ENUM('Male', 'Female'),
    birthdate DATE,
    
    is_active BOOLEAN DEFAULT TRUE,
    archived_at DATETIME NULL,
    date_registered DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id) ON DELETE RESTRICT,
    FOREIGN KEY (category_id) REFERENCES student_category(category_id) ON DELETE RESTRICT,
    FOREIGN KEY (class_id) REFERENCES class(class_id) ON DELETE SET NULL,
    
    INDEX idx_lrn (lrn),
    INDEX idx_teacher (teacher_id),
    INDEX idx_grade (category_id),
    INDEX idx_active (is_active),
    INDEX idx_name (last_name, first_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 8. PARENT TABLE
-- ============================================================

CREATE TABLE parent (
    parent_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    contact_number VARCHAR(20),
    
    FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE,
    
    INDEX idx_email (email),
    INDEX idx_name (last_name, first_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 9. STUDENT-PARENT (Many-to-Many)
-- ============================================================

CREATE TABLE student_parent (
    student_parent_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    parent_id INT NOT NULL,
    relationship ENUM('Mother', 'Father', 'Guardian') NOT NULL,
    
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES parent(parent_id) ON DELETE CASCADE,
    
    UNIQUE KEY unique_student_parent (student_id, parent_id),
    INDEX idx_student (student_id),
    INDEX idx_parent (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 10. READING MATERIAL TABLE
-- ============================================================

CREATE TABLE reading_material (
    material_id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    language ENUM('English', 'Filipino') NOT NULL,
    material_type ENUM('Phil-IRI', 'CRLA', 'Practice', 'Custom') NOT NULL,
    grade_level ENUM('Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6') NOT NULL,
    difficulty ENUM('Easy', 'Average', 'Hard') DEFAULT 'Average',
    original_filename VARCHAR(255),
    file_path VARCHAR(255) NOT NULL,
    ocr_text LONGTEXT,
    total_words INT DEFAULT 0,
    upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Active', 'Archived') DEFAULT 'Active',
    
    FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id) ON DELETE RESTRICT,
    
    INDEX idx_teacher (teacher_id),
    INDEX idx_grade (grade_level),
    INDEX idx_language (language),
    INDEX idx_status (status),
    FULLTEXT INDEX idx_ocr_text (ocr_text)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 11. READING ACTIVITY TABLE
-- ============================================================

CREATE TABLE reading_activity (
    activity_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    material_id INT NOT NULL,
    activity_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    started_at DATETIME,
    finished_at DATETIME,
    audio_filename VARCHAR(255),
    audio_path VARCHAR(255),
    duration_seconds INT,
    attempt_number INT DEFAULT 1,
    activity_status ENUM('Pending', 'Processing', 'Completed') DEFAULT 'Pending',
    
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    FOREIGN KEY (material_id) REFERENCES reading_material(material_id) ON DELETE CASCADE,
    
    INDEX idx_student (student_id),
    INDEX idx_material (material_id),
    INDEX idx_date (activity_date),
    INDEX idx_status (activity_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 12. ASSESSMENT RESULT TABLE
-- ============================================================

CREATE TABLE assessment_result (
    assessment_id INT AUTO_INCREMENT PRIMARY KEY,
    activity_id INT NOT NULL,
    
    -- Reading Statistics
    total_words INT NOT NULL,
    words_correct INT NOT NULL,
    accuracy_percentage DECIMAL(5,2),
    wcpm DECIMAL(6,2),
    reading_time_seconds INT,
    
    -- Miscue Analysis
    substitutions INT DEFAULT 0,
    omissions INT DEFAULT 0,
    insertions INT DEFAULT 0,
    repetitions INT DEFAULT 0,
    self_corrections INT DEFAULT 0,
    
    transcript LONGTEXT,
    reading_level ENUM('Non-reader', 'Frustration', 'Instructional', 'Independent'),
    teacher_feedback TEXT,
    
    -- CRLA Specific Fields
    part1_task1_score INT DEFAULT 0,
    part1_words_score INT DEFAULT 0,
    part1_total_score INT DEFAULT 0,
    part1_reading_level VARCHAR(50),
    story_number INT,
    miscues INT DEFAULT 0,
    words_read INT DEFAULT 0,
    minutes INT DEFAULT 0,
    seconds INT DEFAULT 0,
    comprehension_score INT DEFAULT 0,
    final_reading_level VARCHAR(50),
    observation_level ENUM('Level 1', 'Level 2', 'Level 3', 'Level 4'),
    
    -- ORF Metrics
    pronunciation_score DECIMAL(5,2),
    fluency_score DECIMAL(5,2),
    expression_score DECIMAL(5,2),
    
    assessed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (activity_id) REFERENCES reading_activity(activity_id) ON DELETE CASCADE,
    
    INDEX idx_activity (activity_id),
    INDEX idx_assessed_at (assessed_at),
    INDEX idx_reading_level (reading_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 13. PROGRESS RECORD TABLE
-- ============================================================

CREATE TABLE progress_record (
    progress_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    assessment_id INT NOT NULL,
    teacher_id INT NOT NULL,
    performance_level ENUM('Non-reader', 'Frustration', 'Instructional', 'Independent'),
    remarks TEXT,
    record_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    FOREIGN KEY (assessment_id) REFERENCES assessment_result(assessment_id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id) ON DELETE CASCADE,
    
    INDEX idx_student (student_id),
    INDEX idx_teacher (teacher_id),
    INDEX idx_record_date (record_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 14. READING ERRORS TABLE (Detailed Miscue Analysis)
-- ============================================================

CREATE TABLE reading_errors (
    error_id INT AUTO_INCREMENT PRIMARY KEY,
    assessment_id INT NOT NULL,
    expected_word VARCHAR(100),
    spoken_word VARCHAR(100),
    error_type ENUM('Correct', 'Substitution', 'Insertion', 'Omission', 'Mispronunciation'),
    word_position INT,
    
    FOREIGN KEY (assessment_id) REFERENCES assessment_result(assessment_id) ON DELETE CASCADE,
    
    INDEX idx_assessment (assessment_id),
    INDEX idx_error_type (error_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 15. CRLA CRITERIA TABLE (For Assessment Scoring)
-- ============================================================

CREATE TABLE crla_criteria (
    criteria_id INT AUTO_INCREMENT PRIMARY KEY,
    grade_level ENUM('Grade 1', 'Grade 2', 'Grade 3'),
    assessment_part ENUM('Part 1', 'Part 2'),
    minimum_score INT,
    maximum_score INT,
    minimum_accuracy DECIMAL(5,2),
    maximum_accuracy DECIMAL(5,2),
    minimum_questions INT,
    maximum_questions INT,
    reading_level VARCHAR(50),
    observation_level VARCHAR(20),
    
    INDEX idx_grade (grade_level),
    INDEX idx_part (assessment_part)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 16. NOTIFICATION TABLE
-- ============================================================

CREATE TABLE notification (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(150),
    message TEXT,
    status ENUM('Unread', 'Read') DEFAULT 'Unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE,
    
    INDEX idx_user (user_id),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 17. LOGIN LOGS TABLE
-- ============================================================

CREATE TABLE login_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    logout_time DATETIME,
    ip_address VARCHAR(45),
    device_info VARCHAR(255),
    
    FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE,
    
    INDEX idx_user (user_id),
    INDEX idx_login_time (login_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 18. IMPORT HISTORY TABLE
-- ============================================================

CREATE TABLE import_history (
    import_id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    total_records INT NOT NULL DEFAULT 0,
    successful_imports INT NOT NULL DEFAULT 0,
    skipped_records INT NOT NULL DEFAULT 0,
    imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id) ON DELETE CASCADE,
    
    INDEX idx_teacher (teacher_id),
    INDEX idx_imported_at (imported_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 19. SAMPLE DATA (Required for testing)
-- ============================================================

-- Users (password: 'password123' hashed)
INSERT INTO user (username, password, role, status) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'Active'),
('principal1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Principal', 'Active'),
('teacher1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Teacher', 'Active');

-- Teacher Categories
INSERT INTO teacher_category (grade_level, section, school_year) VALUES
('Grade 2', 'Section A', '2025-2026'),
('Grade 2', 'Section B', '2025-2026'),
('Grade 3', 'Section A', '2025-2026'),
('Grade 3', 'Section B', '2025-2026');

-- Teacher
INSERT INTO teacher (user_id, teacher_category_id, employee_no, first_name, last_name, email) VALUES
(3, 1, 'T001', 'Maria', 'Dela Cruz', 'maria.delacruz@school.edu.ph');

-- Student Categories
INSERT INTO student_category (grade_level, school_year) VALUES
('Grade 2', '2025-2026'),
('Grade 3', '2025-2026');

-- Classes
INSERT INTO class (teacher_id, grade_level, section, school_year) VALUES
(1, 'Grade 2', 'Section A', '2025-2026'),
(1, 'Grade 2', 'Section B', '2025-2026'),
(1, 'Grade 3', 'Section A', '2025-2026'),
(1, 'Grade 3', 'Section B', '2025-2026');

-- Students (with 6-digit LRN)
INSERT INTO student (lrn, teacher_id, category_id, class_id, first_name, middle_name, last_name, gender, birthdate, is_active) VALUES
('123456', 1, 1, 1, 'Juan', 'Santos', 'Dela Cruz', 'Male', '2016-05-15', 1),
('123457', 1, 1, 1, 'Maria', 'Reyes', 'Garcia', 'Female', '2016-08-22', 1),
('123458', 1, 1, 2, 'Jose', 'Mendoza', 'Luna', 'Male', '2016-11-02', 1),
('123459', 1, 2, 3, 'Ana', 'Cruz', 'Martinez', 'Female', '2015-03-10', 1),
('123460', 1, 2, 3, 'Pedro', 'Ramos', 'Santos', 'Male', '2015-07-19', 1);

-- CRLA Criteria
INSERT INTO crla_criteria (grade_level, assessment_part, minimum_score, maximum_score, reading_level, observation_level) VALUES
('Grade 3', 'Part 1', 0, 10, 'Low Emerging Reader', 'Level 1'),
('Grade 3', 'Part 2', 0, 25, 'High Emerging Reader', 'Level 1'),
('Grade 3', 'Part 2', 26, 50, 'Developing Reader', 'Level 2'),
('Grade 3', 'Part 2', 51, 75, 'Transitioning Reader', 'Level 3'),
('Grade 3', 'Part 2', 76, 100, 'Reading At Grade Level', 'Level 4');

-- Sample Reading Materials
INSERT INTO reading_material (teacher_id, title, description, language, material_type, grade_level, difficulty, file_path, total_words, status) VALUES
(1, 'Ang Batang Matulungin', 'A Filipino story about a helpful child', 'Filipino', 'CRLA', 'Grade 2', 'Easy', '/materials/ang_batang_matulungin.txt', 120, 'Active'),
(1, 'The Helpful Boy', 'An English story about kindness', 'English', 'Phil-IRI', 'Grade 2', 'Average', '/materials/the_helpful_boy.txt', 150, 'Active');

-- ============================================================
-- 20. VERIFY ALL TABLES
-- ============================================================

SELECT 'Tables created successfully!' as 'Status';
SHOW TABLES;

-- Count records
SELECT 'Users' as 'Table', COUNT(*) as 'Count' FROM user
UNION ALL SELECT 'Teachers', COUNT(*) FROM teacher
UNION ALL SELECT 'Students', COUNT(*) FROM student
UNION ALL SELECT 'Reading Materials', COUNT(*) FROM reading_material;