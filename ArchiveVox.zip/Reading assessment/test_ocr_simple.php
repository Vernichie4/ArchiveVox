<?php
// Include the OCR file first
require_once __DIR__ . '/php/backend/ocr.php';

echo "<h2>Testing Tesseract</h2>";

// Check if Tesseract exists
$paths = [
    'D:\\Program Files\\Tesseract-OCR\\tesseract.exe',
    'C:\\Program Files\\Tesseract-OCR\\tesseract.exe',
];

foreach ($paths as $path) {
    if (file_exists($path)) {
        echo "<p style='color: green;'>✅ Found: " . htmlspecialchars($path) . "</p>";
    } else {
        echo "<p style='color: red;'>❌ NOT found: " . htmlspecialchars($path) . "</p>";
    }
}

// Try to get the executable path
try {
    $tesseract = getTesseractExecutable();
    echo "<p style='color: green;'>✅ Tesseract executable: " . htmlspecialchars($tesseract) . "</p>";
    
    // Try to run a simple OCR test
    echo "<h3>Testing OCR with a simple image...</h3>";
    echo "<p>You need to upload an image to test OCR. Go to the Reading Materials tab.</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

// Check if uploads folder exists
$uploadDir = __DIR__ . '/uploads/materials/';
if (is_dir($uploadDir)) {
    echo "<p style='color: green;'>✅ Uploads folder exists: " . htmlspecialchars($uploadDir) . "</p>";
} else {
    echo "<p style='color: red;'>❌ Uploads folder does NOT exist. Creating it...</p>";
    if (mkdir($uploadDir, 0777, true)) {
        echo "<p style='color: green;'>✅ Created uploads folder successfully!</p>";
    } else {
        echo "<p style='color: red;'>❌ Failed to create uploads folder. Please create it manually.</p>";
    }
}

// Check temp folder
$tempDir = __DIR__ . '/uploads/temp/';
if (is_dir($tempDir)) {
    echo "<p style='color: green;'>✅ Temp folder exists: " . htmlspecialchars($tempDir) . "</p>";
} else {
    echo "<p style='color: red;'>❌ Temp folder does NOT exist. Creating it...</p>";
    if (mkdir($tempDir, 0777, true)) {
        echo "<p style='color: green;'>✅ Created temp folder successfully!</p>";
    } else {
        echo "<p style='color: red;'>❌ Failed to create temp folder. Please create it manually.</p>";
    }
}
?>