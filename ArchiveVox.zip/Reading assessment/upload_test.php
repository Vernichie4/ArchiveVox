<?php
// Fix: Include the OCR file properly
require_once __DIR__ . '/php/backend/ocr.php';

$uploadDir = __DIR__ . '/uploads/materials/';

// Create folder if it doesn't exist
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
    echo "📁 Created uploads folder<br>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $file = $_FILES['image'];
    $filename = time() . '_' . basename($file['name']);
    $filePath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        echo "<h2 style='color: green;'>✅ File uploaded successfully!</h2>";
        echo "<p><strong>File:</strong> " . htmlspecialchars($filename) . "</p>";
        echo "<p><strong>Size:</strong> " . round($file['size'] / 1024) . " KB</p>";
        echo "<p><strong>Saved to:</strong> " . htmlspecialchars($filePath) . "</p>";
        
        // Try OCR on the uploaded file
        echo "<h3>Testing OCR...</h3>";
        try {
            $text = runOcr($filePath, 'eng');
            echo "<p style='color: green;'>✅ OCR Successful!</p>";
            echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px; overflow: auto; max-height: 300px;'>" . htmlspecialchars($text) . "</pre>";
            echo "<p><strong>Word Count:</strong> " . str_word_count($text) . "</p>";
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ OCR Failed: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    } else {
        echo "<h2 style='color: red;'>❌ Upload failed!</h2>";
        echo "<p>Check folder permissions.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Test</title>
    <style>
        body { font-family: Arial; padding: 20px; max-width: 800px; margin: 0 auto; }
        .upload-area { border: 2px dashed #ccc; padding: 40px; text-align: center; border-radius: 10px; margin: 20px 0; }
        button { background: #2563eb; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; }
        button:hover { background: #1d4ed8; }
    </style>
</head>
<body>
    <h1>📤 Test OCR Upload</h1>
    <div class="upload-area">
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="image" accept="image/*" required style="margin: 10px 0;">
            <br>
            <button type="submit">Upload & OCR</button>
        </form>
    </div>
    <p style="color: #666; font-size: 0.9rem;">
        📌 Upload an image with clear text to test OCR functionality.
    </p>
</body>
</html>