<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ArchiveVox - Reading Assessment Portal</title>
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
    <!-- ============================================ -->
    <!-- LOGIN VIEW -->
    <!-- ============================================ -->
    <div id="login-view" class="login-shell">
        <div class="card login-card">
            <div class="login-header">
                <div class="logo">📚 ArchiveVox</div>
                <p class="subtitle">Reading Assessment Portal</p>
            </div>
            <form id="login-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input id="username" name="username" type="text" placeholder="Enter your username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" placeholder="Enter your password" required>
                </div>
                <button type="submit" class="btn-primary">Sign In</button>
                <a href="#" class="forgot-password">Forgot password?</a>
            </form>
            <p class="hint">Demo: teacher1 / password123</p>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- APP SHELL (Hidden until login) -->
    <!-- ============================================ -->
    <div id="app-shell" class="hidden">
        <!-- Top Bar -->
        <header class="topbar" id="topbar">
            <div class="topbar-left">
                <div class="logo-small">📚 ArchiveVox</div>
                <span id="role-badge" class="role-badge">Teacher</span>
            </div>
            <div class="topbar-center">
                <span id="current-date"></span>
            </div>
            <div class="topbar-actions">
                <span id="user-badge">Guest</span>
                <button id="settings-btn" class="icon-btn">⚙️</button>
                <button id="logout-btn" class="btn-secondary">Sign Out</button>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="nav-tabs" id="nav-container">
            <!-- Dynamically rendered by JavaScript -->
        </nav>

        <!-- Main Content -->
        <main id="view-container" class="view-container"></main>
    </div>

    <script src="assets/app.js"></script>
</body>
</html>