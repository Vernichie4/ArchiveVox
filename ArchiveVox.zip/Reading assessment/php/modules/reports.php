<?php
require_once __DIR__ . '/../auth/config.php';

function getTeacherDashboard(int $teacherId): array {
    global $pdo;
    
    try {
        // Get total students for this teacher
        $stmt = $pdo->prepare('
            SELECT COUNT(*) as total 
            FROM student 
            WHERE teacher_id = :teacher_id AND is_active = 1
        ');
        $stmt->execute([':teacher_id' => $teacherId]);
        $studentCount = $stmt->fetch();
        $myStudents = $studentCount ? (int)$studentCount['total'] : 0;
        
        // Get class average WCPM
        $stmt = $pdo->prepare('
            SELECT AVG(ar.wcpm) as avg_wcpm
            FROM assessment_result ar
            JOIN reading_activity ra ON ar.activity_id = ra.activity_id
            JOIN student s ON ra.student_id = s.student_id
            WHERE s.teacher_id = :teacher_id
            AND ar.wcpm > 0
        ');
        $stmt->execute([':teacher_id' => $teacherId]);
        $avgWcpm = $stmt->fetch();
        $classAvgWcpm = $avgWcpm && $avgWcpm['avg_wcpm'] ? (float)$avgWcpm['avg_wcpm'] : 0;
        
        // Get total assessments for this teacher's students (this month)
        $stmt = $pdo->prepare('
            SELECT COUNT(*) as total
            FROM assessment_result ar
            JOIN reading_activity ra ON ar.activity_id = ra.activity_id
            JOIN student s ON ra.student_id = s.student_id
            WHERE s.teacher_id = :teacher_id
            AND ar.assessed_at >= DATE_FORMAT(CURDATE(), "%Y-%m-01")
        ');
        $stmt->execute([':teacher_id' => $teacherId]);
        $assessments = $stmt->fetch();
        $myAssessments = $assessments ? (int)$assessments['total'] : 0;
        
        // Get recent assessments (last 5)
        $stmt = $pdo->prepare('
            SELECT 
                CONCAT(s.first_name, " ", s.last_name) as student_name,
                ar.accuracy_percentage,
                ar.fluency_score,
                ar.wcpm,
                ar.miscues,
                ar.comprehension_score,
                ar.assessed_at
            FROM assessment_result ar
            JOIN reading_activity ra ON ar.activity_id = ra.activity_id
            JOIN student s ON ra.student_id = s.student_id
            WHERE s.teacher_id = :teacher_id
            ORDER BY ar.assessed_at DESC
            LIMIT 5
        ');
        $stmt->execute([':teacher_id' => $teacherId]);
        $recentAssessments = $stmt->fetchAll();
        
        // Get class performance data for charts (by grade level)
        $stmt = $pdo->prepare('
            SELECT 
                s.grade_level,
                AVG(ar.accuracy_percentage) as avg_accuracy,
                AVG(ar.fluency_score) as avg_fluency,
                AVG(ar.wcpm) as avg_rate
            FROM assessment_result ar
            JOIN reading_activity ra ON ar.activity_id = ra.activity_id
            JOIN student s ON ra.student_id = s.student_id
            WHERE s.teacher_id = :teacher_id
            AND ar.accuracy_percentage > 0
            GROUP BY s.grade_level
        ');
        $stmt->execute([':teacher_id' => $teacherId]);
        $classPerformance = $stmt->fetchAll();
        
        return [
            'my_students' => $myStudents,
            'class_avg_wcpm' => $classAvgWcpm,
            'my_assessments' => $myAssessments,
            'recent_assessments' => $recentAssessments,
            'class_performance' => $classPerformance
        ];
        
    } catch (PDOException $e) {
        return [
            'my_students' => 0,
            'class_avg_wcpm' => 0,
            'my_assessments' => 0,
            'recent_assessments' => [],
            'class_performance' => [],
            'error' => $e->getMessage()
        ];
    }
}

// Existing functions...
function teacherDashboard(): array {
    global $pdo;

    $studentCount = (int) $pdo->query('SELECT COUNT(*) FROM student')->fetchColumn();
    $recentAssessments = $pdo->query('SELECT assessment_id, wcpm, assessed_at FROM assessment_result ORDER BY assessed_at DESC LIMIT 5')->fetchAll();
    $avgWcpm = (float) $pdo->query('SELECT AVG(wcpm) FROM assessment_result')->fetchColumn();

    return [
        'student_count' => $studentCount,
        'recent_assessments' => $recentAssessments,
        'average_wcpm' => $avgWcpm,
    ];
}

function principalDashboard(): array {
    global $pdo;

    $readingLevels = $pdo->query('SELECT reading_level, COUNT(*) as total FROM assessment_result GROUP BY reading_level')->fetchAll();
    $gradeLevels = $pdo->query('SELECT grade_level, COUNT(*) as total FROM reading_material GROUP BY grade_level')->fetchAll();

    return [
        'reading_level_distribution' => $readingLevels,
        'grade_level_distribution' => $gradeLevels,
    ];
}