<?php
require_once __DIR__ . '/../auth/config.php';

function parseImportFile(string $filePath): array {
    $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    
    if ($extension === 'csv') {
        return parseCsvFile($filePath);
    } elseif ($extension === 'xlsx') {
        return parseXlsxFile($filePath);
    } else {
        throw new RuntimeException('Only .csv and .xlsx files are supported.');
    }
}

function parseCsvFile(string $filePath): array {
    $rows = [];
    $handle = fopen($filePath, 'r');
    if ($handle === false) {
        throw new RuntimeException('Unable to read uploaded file.');
    }
    
    $delimiters = [',', ';', "\t"];
    $delimiter = ',';
    $firstLine = fgets($handle);
    rewind($handle);
    
    foreach ($delimiters as $d) {
        if (strpos($firstLine, $d) !== false) {
            $delimiter = $d;
            break;
        }
    }
    
    while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
        $rows[] = $row;
    }
    
    fclose($handle);
    return normalizeImportRows($rows);
}

function parseXlsxFile(string $filePath): array {
    $zip = new ZipArchive();
    if ($zip->open($filePath) !== true) {
        throw new RuntimeException('Unable to read Excel file.');
    }
    
    $sharedStrings = [];
    $sharedStringsXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($sharedStringsXml !== false) {
        $sharedStringsXmlObj = simplexml_load_string($sharedStringsXml);
        if ($sharedStringsXmlObj !== false) {
            foreach ($sharedStringsXmlObj->si as $si) {
                $text = '';
                foreach ($si->t as $t) {
                    $text .= (string) $t;
                }
                $sharedStrings[] = $text;
            }
        }
    }
    
    $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
    $zip->close();
    
    if ($sheetXml === false) {
        throw new RuntimeException('Unable to read worksheet data from Excel file.');
    }
    
    $sheetXmlObj = simplexml_load_string($sheetXml);
    if ($sheetXmlObj === false) {
        throw new RuntimeException('Unable to parse worksheet data.');
    }
    
    $rows = [];
    foreach ($sheetXmlObj->sheetData->row as $row) {
        $values = [];
        foreach ($row->c as $cell) {
            $cellType = (string) ($cell['t'] ?? '');
            $value = '';
            if (isset($cell->v)) {
                $value = (string) $cell->v;
            }
            
            if ($cellType === 's' && isset($sharedStrings[(int) $value])) {
                $value = $sharedStrings[(int) $value];
            }
            
            $values[] = $value;
        }
        $rows[] = $values;
    }
    
    return normalizeImportRows($rows);
}

function normalizeImportRows(array $rows): array {
    if (!$rows) {
        return [];
    }
    
    $headerCells = array_map('trim', array_values($rows[0]));
    $isHeaderRow = false;
    $headerMap = [];
    
    $possibleHeaders = [
        'lrn' => ['lrn', 'learner reference number', 'student no', 'student number', 'id'],
        'first_name' => ['first name', 'firstname', 'fname', 'given name', 'first'],
        'last_name' => ['last name', 'lastname', 'lname', 'surname', 'last'],
        'middle_name' => ['middle name', 'middlename', 'mname', 'middle'],
        'grade_level' => ['grade', 'grade level', 'level', 'year'],
        'section' => ['section', 'class', 'division'],
        'gender' => ['gender', 'sex'],
        'birthdate' => ['birthdate', 'birth date', 'dob', 'date of birth']
    ];
    
    foreach ($headerCells as $index => $cell) {
        $cellLower = strtolower(trim($cell));
        foreach ($possibleHeaders as $field => $keywords) {
            foreach ($keywords as $keyword) {
                if (strpos($cellLower, $keyword) !== false) {
                    $isHeaderRow = true;
                    $headerMap[$field] = $index;
                    break 2;
                }
            }
        }
    }
    
    $dataRows = $isHeaderRow ? array_slice($rows, 1) : $rows;
    $normalized = [];
    
    foreach ($dataRows as $row) {
        $cells = array_values($row);
        $cells = array_pad($cells, 8, '');
        
        $normalizedRow = [
            'lrn' => '',
            'first_name' => '',
            'last_name' => '',
            'middle_name' => '',
            'grade_level' => '',
            'section' => '',
            'gender' => '',
            'birthdate' => ''
        ];
        
        if ($isHeaderRow && !empty($headerMap)) {
            foreach ($headerMap as $field => $index) {
                if (isset($cells[$index])) {
                    $normalizedRow[$field] = trim((string) $cells[$index]);
                }
            }
        } else {
            // Default order: lrn, first_name, last_name, middle_name, grade_level, section, gender, birthdate
            $normalizedRow['lrn'] = trim((string) ($cells[0] ?? ''));
            $normalizedRow['first_name'] = trim((string) ($cells[1] ?? ''));
            $normalizedRow['last_name'] = trim((string) ($cells[2] ?? ''));
            $normalizedRow['middle_name'] = trim((string) ($cells[3] ?? ''));
            $normalizedRow['grade_level'] = trim((string) ($cells[4] ?? ''));
            $normalizedRow['section'] = trim((string) ($cells[5] ?? ''));
            $normalizedRow['gender'] = trim((string) ($cells[6] ?? ''));
            $normalizedRow['birthdate'] = trim((string) ($cells[7] ?? ''));
        }
        
        if (!empty($normalizedRow['first_name']) || !empty($normalizedRow['last_name'])) {
            $normalized[] = $normalizedRow;
        }
    }
    
    return $normalized;
}

function previewStudents(array $rows): array {
    $validRows = [];
    $errors = [];
    
    foreach ($rows as $index => $row) {
        $record = [
            'row_number' => $index + 2,
            'lrn' => $row['lrn'] ?? '',
            'first_name' => $row['first_name'] ?? '',
            'last_name' => $row['last_name'] ?? '',
            'middle_name' => $row['middle_name'] ?? '',
            'grade_level' => $row['grade_level'] ?? '',
            'section' => $row['section'] ?? '',
            'gender' => $row['gender'] ?? '',
            'birthdate' => $row['birthdate'] ?? '',
            'status' => 'valid',
            'message' => ''
        ];
        
        if (empty($record['first_name']) && empty($record['last_name'])) {
            $record['status'] = 'error';
            $record['message'] = 'Missing name';
            $errors[] = $record;
        } elseif (empty($record['first_name'])) {
            $record['status'] = 'error';
            $record['message'] = 'Missing first name';
            $errors[] = $record;
        } elseif (empty($record['last_name'])) {
            $record['status'] = 'error';
            $record['message'] = 'Missing last name';
            $errors[] = $record;
        } else {
            $validRows[] = $record;
        }
    }
    
    return [
        'rows' => $validRows,
        'errors' => $errors,
        'summary' => [
            'total' => count($rows),
            'valid' => count($validRows),
            'errors' => count($errors),
        ]
    ];
}

function importStudents(array $rows, int $teacherId): array {
    global $pdo;
    
    $successfulImports = 0;
    $skippedRecords = 0;
    $errors = [];
    
    foreach ($rows as $row) {
        $lrn = trim((string) ($row['lrn'] ?? ''));
        $firstName = trim((string) ($row['first_name'] ?? ''));
        $lastName = trim((string) ($row['last_name'] ?? ''));
        $middleName = trim((string) ($row['middle_name'] ?? ''));
        $gradeLevel = trim((string) ($row['grade_level'] ?? 'Grade 2'));
        $section = trim((string) ($row['section'] ?? ''));
        $gender = normalizeGender((string) ($row['gender'] ?? ''));
        $birthdate = normalizeDate((string) ($row['birthdate'] ?? ''));
        
        if ($firstName === '' || $lastName === '') {
            $skippedRecords++;
            $errors[] = 'Row missing required fields: ' . $firstName . ' ' . $lastName;
            continue;
        }
        
        if (!empty($lrn)) {
            $stmt = $pdo->prepare('SELECT student_id FROM student WHERE lrn = :lrn');
            $stmt->execute([':lrn' => $lrn]);
            if ($stmt->fetch()) {
                $skippedRecords++;
                continue;
            }
        }
        
        $categoryId = getOrCreateCategory($gradeLevel);
        $classId = getOrCreateClass($teacherId, $gradeLevel, $section);
        
        try {
            $stmt = $pdo->prepare('
                INSERT INTO student (
                    teacher_id, category_id, class_id, lrn,
                    first_name, middle_name, last_name,
                    gender, birthdate, is_active
                ) VALUES (
                    :teacher_id, :category_id, :class_id, :lrn,
                    :first_name, :middle_name, :last_name,
                    :gender, :birthdate, 1
                )
            ');
            
            $stmt->execute([
                ':teacher_id' => $teacherId,
                ':category_id' => $categoryId,
                ':class_id' => $classId,
                ':lrn' => $lrn ?: null,
                ':first_name' => $firstName,
                ':middle_name' => $middleName ?: null,
                ':last_name' => $lastName,
                ':gender' => $gender,
                ':birthdate' => $birthdate,
            ]);
            
            $successfulImports++;
        } catch (PDOException $e) {
            $skippedRecords++;
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
    
    return [
        'success' => true,
        'summary' => [
            'total' => count($rows),
            'imported' => $successfulImports,
            'skipped' => $skippedRecords,
            'errors' => count($errors),
        ],
        'errors' => $errors
    ];
}

function getOrCreateCategory(string $gradeLevel): int {
    global $pdo;
    
    $stmt = $pdo->prepare('SELECT category_id FROM student_category WHERE grade_level = :grade_level LIMIT 1');
    $stmt->execute([':grade_level' => $gradeLevel]);
    $category = $stmt->fetch();
    
    if ($category) {
        return (int) $category['category_id'];
    }
    
    $stmt = $pdo->prepare('INSERT INTO student_category (grade_level, school_year) VALUES (:grade_level, :school_year)');
    $schoolYear = date('Y') . '-' . (date('Y') + 1);
    $stmt->execute([
        ':grade_level' => $gradeLevel,
        ':school_year' => $schoolYear
    ]);
    
    return (int) $pdo->lastInsertId();
}

function getOrCreateClass(int $teacherId, string $gradeLevel, string $section): ?int {
    global $pdo;
    
    if (empty($section)) {
        return null;
    }
    
    $stmt = $pdo->prepare('
        SELECT class_id FROM class 
        WHERE teacher_id = :teacher_id AND grade_level = :grade_level AND section = :section
        LIMIT 1
    ');
    $stmt->execute([
        ':teacher_id' => $teacherId,
        ':grade_level' => $gradeLevel,
        ':section' => $section
    ]);
    $class = $stmt->fetch();
    
    if ($class) {
        return (int) $class['class_id'];
    }
    
    $stmt = $pdo->prepare('
        INSERT INTO class (teacher_id, grade_level, section, school_year) 
        VALUES (:teacher_id, :grade_level, :section, :school_year)
    ');
    $schoolYear = date('Y') . '-' . (date('Y') + 1);
    $stmt->execute([
        ':teacher_id' => $teacherId,
        ':grade_level' => $gradeLevel,
        ':section' => $section,
        ':school_year' => $schoolYear
    ]);
    
    return (int) $pdo->lastInsertId();
}

function normalizeGender(string $value): ?string {
    $value = strtolower(trim($value));
    if (in_array($value, ['male', 'm', 'boy', '1'])) {
        return 'Male';
    }
    if (in_array($value, ['female', 'f', 'girl', '2'])) {
        return 'Female';
    }
    return null;
}

function normalizeDate(string $value): ?string {
    $value = trim($value);
    if ($value === '') {
        return null;
    }
    
    $formats = ['Y-m-d', 'm/d/Y', 'm-d-Y', 'd/m/Y', 'd-m-Y', 'Y/m/d'];
    foreach ($formats as $format) {
        $date = DateTimeImmutable::createFromFormat($format, $value);
        if ($date !== false) {
            return $date->format('Y-m-d');
        }
    }
    
    return null;
}