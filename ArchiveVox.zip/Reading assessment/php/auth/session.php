<?php
require_once __DIR__ . '/config.php';

function loginUser(array $user): void {
    $_SESSION['user'] = $user;
    $_SESSION['logged_in_at'] = time();
}

function logoutUser(): void {
    session_unset();
    session_destroy();
}

function isLoggedIn(): bool {
    return !empty($_SESSION['user']);
}

function currentUser(): ?array {
    return $_SESSION['user'] ?? null;
}