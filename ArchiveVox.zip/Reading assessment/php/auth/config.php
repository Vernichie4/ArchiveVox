<?php
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../connection.php';

$pdo = createPdoConnection();
session_start();
