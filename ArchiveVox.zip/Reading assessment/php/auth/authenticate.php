<?php
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/config.php';

function authenticateUser(string $username, string $password): ?array {
    global $pdo;

    try {
        $stmt = $pdo->prepare(
            'SELECT user_id, username, password, role, status FROM user WHERE username = :username LIMIT 1'
        );
        $stmt->execute([':username' => $username]);
        $user = $stmt->fetch();

        if (!$user) {
            return null;
        }

        if ($user['status'] !== 'Active') {
            return null;
        }

        if (!password_verify($password, $user['password'])) {
            return null;
        }

        return [
            'user_id' => (int) $user['user_id'],
            'username' => $user['username'],
            'role' => $user['role'],
        ];
    } catch (Exception $e) {
        error_log('Authentication error: ' . $e->getMessage());
        return null;
    }
}