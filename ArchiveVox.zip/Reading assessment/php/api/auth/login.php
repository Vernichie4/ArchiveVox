<?php
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');

require_once __DIR__ . '/../../auth/config.php';
require_once __DIR__ . '/../../auth/authenticate.php';
require_once __DIR__ . '/../../auth/session.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// 🔥 FIX: Read JSON input from the request body
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Get username and password from JSON data
$username = trim($data['username'] ?? '');
$password = trim($data['password'] ?? '');

if ($username === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username and password are required.']);
    exit;
}

$user = authenticateUser($username, $password);

if ($user === null) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
    exit;
}

loginUser($user);

echo json_encode([
    'success' => true,
    'message' => 'Login successful.',
    'user' => $user
]);