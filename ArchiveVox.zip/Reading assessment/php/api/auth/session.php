<?php
require_once __DIR__ . '/../../auth/config.php';
require_once __DIR__ . '/../../auth/session.php';

header('Content-Type: application/json');

if (isLoggedIn()) {
    echo json_encode(['success' => true, 'user' => currentUser()]);
} else {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated.']);
}