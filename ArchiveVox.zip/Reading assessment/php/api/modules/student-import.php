<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../../auth/config.php';
require_once __DIR__ . '/../../modules/student_import.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($method) {
        case 'POST':
            if ($action === 'preview') {
                if (empty($_FILES) || !isset($_FILES['file'])) {
                    echo json_encode(['success' => false, 'message' => 'No file uploaded']);
                    break;
                }
                
                $file = $_FILES['file'];
                $uploadDir = __DIR__ . '/../../../uploads/temp/';
                
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $filename = time() . '_' . basename($file['name']);
                $filePath = $uploadDir . $filename;
                
                if (move_uploaded_file($file['tmp_name'], $filePath)) {
                    $rows = parseImportFile($filePath);
                    $preview = previewStudents($rows);
                    
                    unlink($filePath);
                    
                    echo json_encode([
                        'success' => true,
                        'preview' => $preview,
                        'file' => $filename
                    ]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to upload file']);
                }
                
            } elseif ($action === 'import') {
                $data = json_decode(file_get_contents('php://input'), true);
                
                if (!$data || !isset($data['rows'])) {
                    echo json_encode(['success' => false, 'message' => 'No data to import']);
                    break;
                }
                
                $user = $_SESSION['user'] ?? null;
                if (!$user) {
                    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
                    break;
                }
                
                $stmt = $pdo->prepare('SELECT teacher_id FROM teacher WHERE user_id = :user_id');
                $stmt->execute([':user_id' => $user['user_id']]);
                $teacher = $stmt->fetch();
                
                if (!$teacher) {
                    echo json_encode(['success' => false, 'message' => 'Teacher record not found']);
                    break;
                }
                
                $result = importStudents($data['rows'], $teacher['teacher_id']);
                echo json_encode($result);
                
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}