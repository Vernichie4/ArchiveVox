<?php
require_once __DIR__ . '/../../auth/config.php';
require_once __DIR__ . '/../../backend/reading_assessment.php';

header('Content-Type: application/json');

// Handle different request methods
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                $assessments = getAssessmentSummary();
                echo json_encode(['success' => true, 'assessments' => $assessments]);
            } else {
                // Get single assessment if ID provided
                $assessmentId = $_GET['id'] ?? 0;
                if ($assessmentId > 0) {
                    $stmt = $pdo->prepare('
                        SELECT ar.*, s.first_name, s.last_name, rm.title as material_title 
                        FROM assessment_result ar
                        JOIN reading_activity ra ON ar.activity_id = ra.activity_id
                        JOIN student s ON ra.student_id = s.student_id
                        JOIN reading_material rm ON ra.material_id = rm.material_id
                        WHERE ar.assessment_id = :id
                    ');
                    $stmt->execute([':id' => $assessmentId]);
                    $assessment = $stmt->fetch();
                    echo json_encode(['success' => true, 'assessment' => $assessment]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Assessment ID required']);
                }
            }
            break;

        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            $result = saveAssessment($data);
            echo json_encode($result);
            break;

        case 'PUT':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            $assessmentId = $_GET['id'] ?? 0;
            if ($assessmentId <= 0) {
                echo json_encode(['success' => false, 'message' => 'Assessment ID required']);
                break;
            }
            
            // Update assessment
            $fields = [];
            $values = [':assessment_id' => $assessmentId];
            
            $allowedFields = [
                'accuracy_percentage', 'wcpm', 'reading_level', 
                'teacher_feedback', 'comprehension_score',
                'pronunciation_score', 'fluency_score', 'expression_score'
            ];
            
            foreach ($data as $key => $value) {
                if (in_array($key, $allowedFields, true)) {
                    $fields[] = $key . ' = :' . $key;
                    $values[':' . $key] = $value;
                }
            }
            
            if (empty($fields)) {
                echo json_encode(['success' => false, 'message' => 'No valid fields to update']);
                break;
            }
            
            $stmt = $pdo->prepare('UPDATE assessment_result SET ' . implode(', ', $fields) . ' WHERE assessment_id = :assessment_id');
            $stmt->execute($values);
            
            echo json_encode(['success' => true, 'message' => 'Assessment updated']);
            break;

        case 'DELETE':
            $assessmentId = $_GET['id'] ?? 0;
            if ($assessmentId <= 0) {
                echo json_encode(['success' => false, 'message' => 'Assessment ID required']);
                break;
            }
            
            $stmt = $pdo->prepare('DELETE FROM assessment_result WHERE assessment_id = :id');
            $stmt->execute([':id' => $assessmentId]);
            
            echo json_encode(['success' => true, 'message' => 'Assessment deleted']);
            break;

        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}