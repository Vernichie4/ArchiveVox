<?php
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../auth/config.php';
require_once __DIR__ . '/../../modules/student_management.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($method) {
        case 'GET':
            if ($action === 'list') {
                // Get teacher's students
                $user = $_SESSION['user'] ?? null;
                if (!$user) {
                    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
                    break;
                }
                
                // Get teacher ID from user ID
                $stmt = $pdo->prepare('SELECT teacher_id FROM teacher WHERE user_id = :user_id');
                $stmt->execute([':user_id' => $user['user_id']]);
                $teacher = $stmt->fetch();
                
                if (!$teacher) {
                    echo json_encode(['success' => false, 'message' => 'Teacher record not found']);
                    break;
                }
                
                $students = getStudentsByTeacher($teacher['teacher_id']);
                echo json_encode(['success' => true, 'students' => $students]);
                
            } elseif ($action === 'search') {
                $term = $_GET['term'] ?? '';
                if (strlen($term) < 1) {
                    echo json_encode(['success' => true, 'students' => []]);
                    break;
                }
                $students = searchStudents($term);
                echo json_encode(['success' => true, 'students' => $students]);
                
            } elseif ($action === 'get') {
                $studentId = $_GET['id'] ?? 0;
                if ($studentId <= 0) {
                    echo json_encode(['success' => false, 'message' => 'Student ID required']);
                    break;
                }
                $student = getStudentById($studentId);
                if ($student) {
                    echo json_encode(['success' => true, 'student' => $student]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Student not found']);
                }
                
            } elseif ($action === 'get-by-lrn') {
                $lrn = $_GET['lrn'] ?? '';
                if (empty($lrn)) {
                    echo json_encode(['success' => false, 'message' => 'LRN required']);
                    break;
                }
                $student = getStudentByLrn($lrn);
                if ($student) {
                    echo json_encode(['success' => true, 'student' => $student]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Student not found']);
                }
                
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
            }
            break;

        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
                break;
            }
            
            // Validate LRN is provided
            if (empty($data['lrn'])) {
                echo json_encode(['success' => false, 'message' => 'LRN is required']);
                break;
            }
            
            // Validate LRN is 6 digits
            if (!preg_match('/^[0-9]{6}$/', $data['lrn'])) {
                echo json_encode(['success' => false, 'message' => 'LRN must be exactly 6 digits']);
                break;
            }
            
            // Get teacher ID from session
            $user = $_SESSION['user'] ?? null;
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'Not authenticated']);
                break;
            }
            
            $stmt = $pdo->prepare('SELECT teacher_id FROM teacher WHERE user_id = :user_id');
            $stmt->execute([':user_id' => $user['user_id']]);
            $teacher = $stmt->fetch();
            
            if (!$teacher) {
                echo json_encode(['success' => false, 'message' => 'Teacher record not found']);
                break;
            }
            
            $data['teacher_id'] = $teacher['teacher_id'];
            $result = registerStudent($data);
            echo json_encode($result);
            break;

        case 'PUT':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
                break;
            }
            
            $studentId = $_GET['id'] ?? 0;
            if ($studentId <= 0) {
                echo json_encode(['success' => false, 'message' => 'Student ID required']);
                break;
            }
            
            $result = editStudent($studentId, $data);
            echo json_encode($result);
            break;

        case 'DELETE':
            $studentId = $_GET['id'] ?? 0;
            if ($studentId <= 0) {
                echo json_encode(['success' => false, 'message' => 'Student ID required']);
                break;
            }
            
            $result = archiveStudent($studentId);
            echo json_encode($result);
            break;

        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}