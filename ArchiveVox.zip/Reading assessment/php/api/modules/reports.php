<?php
require_once __DIR__ . '/../../auth/config.php';
require_once __DIR__ . '/../../modules/reports.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    if ($method === 'GET') {
        if ($action === 'teacher') {
            // Get the logged-in user
            $user = $_SESSION['user'] ?? null;
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'Not authenticated']);
                exit;
            }
            
            // Get teacher ID from user ID
            $stmt = $pdo->prepare('SELECT teacher_id FROM teacher WHERE user_id = :user_id');
            $stmt->execute([':user_id' => $user['user_id']]);
            $teacher = $stmt->fetch();
            
            if (!$teacher) {
                echo json_encode(['success' => false, 'message' => 'Teacher record not found']);
                exit;
            }
            
            $teacherId = $teacher['teacher_id'];
            
            // Get teacher dashboard data
            $dashboard = getTeacherDashboard($teacherId);
            echo json_encode(['success' => true, 'dashboard' => $dashboard]);
            
        } elseif ($action === 'principal') {
            $dashboard = principalDashboard();
            echo json_encode(['success' => true, 'dashboard' => $dashboard]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}