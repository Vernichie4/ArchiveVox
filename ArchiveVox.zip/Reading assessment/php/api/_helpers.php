<?php

function readJsonInput(): array {
    $raw = file_get_contents('php://input');
    if ($raw === '') {
        return [];
    }

    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function sendJson(array $payload, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

function loadAppBackend(): array {
    try {
        // FIXED PATHS - These files are in the correct locations now
        require_once __DIR__ . '/../auth/config.php';
        require_once __DIR__ . '/../auth/authenticate.php';
        require_once __DIR__ . '/../auth/session.php';
        return ['ok' => true];
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}