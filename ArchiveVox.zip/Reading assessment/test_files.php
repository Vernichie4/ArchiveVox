<?php
echo "<h2>Checking Required Files</h2>";

$base = __DIR__;

$files = [
    'php/connection.php',
    'php/auth/config.php',
    'php/auth/authenticate.php',
    'php/auth/session.php',
    'php/api/auth/login.php',
];

foreach ($files as $file) {
    $path = $base . '/' . $file;
    if (file_exists($path)) {
        echo "<p style='color: green;'>✅ " . $file . " exists</p>";
    } else {
        echo "<p style='color: red;'>❌ " . $file . " NOT found</p>";
    }
}