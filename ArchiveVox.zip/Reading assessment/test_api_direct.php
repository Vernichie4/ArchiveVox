<?php
echo "<h2>Testing Login API Directly</h2>";

$url = 'http://localhost/Reading assessment/php/api/auth/login.php';

// Use cURL to test
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'username' => 'teacher1',
    'password' => 'password123'
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);

$response = curl_exec($ch);
$info = curl_getinfo($ch);
curl_close($ch);

echo "<h3>HTTP Status: " . $info['http_code'] . "</h3>";

// Split headers and body
$headerSize = $info['header_size'];
$headers = substr($response, 0, $headerSize);
$body = substr($response, $headerSize);

echo "<h3>Headers:</h3>";
echo "<pre>" . htmlspecialchars($headers) . "</pre>";

echo "<h3>Body:</h3>";
echo "<pre>" . htmlspecialchars($body) . "</pre>";

// Try to parse JSON
$json = json_decode($body, true);
if ($json) {
    echo "<h3 style='color: green;'>✅ Valid JSON!</h3>";
    echo "<pre>";
    print_r($json);
    echo "</pre>";
} else {
    echo "<h3 style='color: red;'>❌ Invalid JSON!</h3>";
}